---
name: Executive Academic Intelligence
colors:
  surface: '#fef7ff'
  surface-dim: '#e2d3fe'
  surface-bright: '#fef7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f1ff'
  surface-container: '#f4eaff'
  surface-container-high: '#efe3ff'
  surface-container-highest: '#eaddff'
  on-surface: '#201636'
  on-surface-variant: '#4a4455'
  inverse-surface: '#352b4c'
  inverse-on-surface: '#f6edff'
  outline: '#7b7486'
  outline-variant: '#ccc3d7'
  surface-tint: '#7331df'
  primary: '#5300b7'
  on-primary: '#ffffff'
  primary-container: '#6d28d9'
  on-primary-container: '#dac5ff'
  inverse-primary: '#d3bbff'
  secondary: '#6f46b9'
  on-secondary: '#ffffff'
  secondary-container: '#b188ff'
  on-secondary-container: '#44118d'
  tertiary: '#4f06b9'
  on-tertiary: '#ffffff'
  tertiary-container: '#6733d0'
  on-tertiary-container: '#d8c6ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ebddff'
  primary-fixed-dim: '#d3bbff'
  on-primary-fixed: '#250059'
  on-primary-fixed-variant: '#5b00c5'
  secondary-fixed: '#ebdcff'
  secondary-fixed-dim: '#d3bbff'
  on-secondary-fixed: '#260059'
  on-secondary-fixed-variant: '#572ba0'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#fef7ff'
  on-background: '#201636'
  surface-variant: '#eaddff'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  data-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.03em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system embodies high-tier academic prestige fused with state-of-the-art computational intelligence. Built for career navigators, high-performing students, and enterprise talent strategists, the interface evokes intellectual authority, precision, and forward momentum.

The design movement combines **Contemporary Editorial Minimalism** with **Atmospheric Layering**:
- **Editorial Hierarchy:** Confident typographic scale contrasts against generous negative space, lending the feeling of a refined analytical journal.
- **Glass & Atmospheric Depth:** Layered translucent surfaces, subtle chromatic reflections, and diffuse violet-tinted atmospheric glows prevent clinical sterility while preserving strict legibility.
- **Precision Metrics & Bento Structuring:** Data structures mimic top-tier executive intelligence suites with crisp, asymmetric bento layouts, fine hairline boundaries, and micro-scale semantic tags.

## Colors

The palette establishes an authoritative visual tiering through controlled chromatic tension between violet spectrum values and clinical, low-luminance neutral backgrounds:

- **Canvas & Primary Surfaces:** `#F5F3FF` serves as the primary canvas tint, providing a warmer, softer base than sterile cold gray. Content panels, cards, and interactive bento boxes leverage `#FFFFFF` for sharp structural definition.
- **Primary Violet Array:**
  - `#6D28D9` anchors primary actionable components, verified credentials, and dominant focal states.
  - `#4C1D95` governs deep contrast elements, selected states, high-priority nodes, and key header accents.
  - `#8B5CF6` delivers energetic illumination for live telemetry, predictive markers, and AI-inferred skill nodes.
- **Text & Hierarchy:**
  - High-density `#1F1535` ensures crisp readability across all data readouts and editorial typography.
  - `#6B6478` handles analytical metadata, graph axes, helper labels, and timestamp indicators.
- **Structural Lines & Accents:**
  - Hairstyle delimiters utilize `#E9E4F3` at 1px constant width.
  - `#16A34A` functions exclusively as an objective semantic validator for mastered competencies, career readiness thresholds, and positive delta values.

## Typography

The type system balances the sculptural modernism of Plus Jakarta Sans with the industrial precision of Inter.

- **Plus Jakarta Sans (Headings, Metrics, Labels):** Applied to top-level structural titles, dynamic numeric KPI readouts, and micro-badges. Its geometric forms provide clean editorial personality without distracting from analytical density.
- **Inter (Body, Tables, Analytical Documentation):** Deployed for descriptions, multi-tiered list views, comparative curriculum texts, and tabular inputs where neutral legibility and uniform vertical flow are essential.
- **Micro-Caps & Numeric Uniformity:** All system indicators, trend labels, and sub-metric tags utilize `label-caps` in uppercase styling with generous tracking (`0.08em`) to enforce clean scannability.

## Layout & Spacing

The interface deploys an asymmetric 12-column dynamic bento grid anchored by a maximum desktop container width of 1440px.

- **Grid Dynamics:**
  - **Desktop (>= 1024px):** 12 columns, 24px (`1.5rem`) gutters, 48px (`3rem`) lateral margins. Bento arrangements combine uneven ratios (e.g., 8:4 column splits for macro skill graphs alongside diagnostic telemetry feeds, or 3:3:6 splits for market readiness cards).
  - **Tablet (768px - 1023px):** 8 columns, 20px gutters, 32px (`2rem`) margins. Secondary metric panels collapse underneath primary graph visualizations.
  - **Mobile (< 768px):** 4 columns, 16px (`1rem`) gutters, 20px (`1.25rem`) margins. Bento units convert to single-column stacking with strict visual spacing priority.
- **Rhythmic Rules:** Component internals apply `space-md` (20px) as standard interior padding. Metric pods with high computational density leverage compact `space-sm` (12px) separation, maintaining clear micro-boundaries via hairline dividers.

## Elevation & Depth

Visual hierarchy uses atmospheric tonal diffusion, soft violet casts, and translucent white surface containers rather than opaque dropshadows:

- **Base Bento Surface (Level 0):** Pure `#FFFFFF` fill with a crisp 1px `#E9E4F3` boundary. Flat, crisp, and grounded.
- **Elevated Analytical Layer (Level 1):** Semi-transparent white (`rgba(255, 255, 255, 0.85)`) over dynamic graph canvases with a `backdrop-filter: blur(16px)` treatment, bounded by a 1px border of `#E9E4F3`. Casts an ambient shadow: `0 12px 32px -4px rgba(109, 40, 217, 0.06), 0 4px 12px -2px rgba(31, 21, 53, 0.03)`.
- **Floating Overlays & Diagnostics (Level 2):** Modals, live AI diagnostic drawers, and active skill breakdown tooltips deploy `rgba(255, 255, 255, 0.95)` with `backdrop-filter: blur(24px)`. Casts a dual-stage shadow: `0 24px 48px -8px rgba(76, 29, 149, 0.12), 0 8px 16px -4px rgba(109, 40, 217, 0.08)`.
- **Active Focus & Glow:** Interactive cards under hover receive a subtle violet ambient rim using `box-shadow: 0 0 0 1px #8B5CF6, 0 16px 36px -6px rgba(109, 40, 217, 0.14)`.

## Shapes

The geometric framework balances clean architectural discipline with smooth modern ergonomics:

- **Macro Containers & Bento Modules:** Default to `rounded-xl` (24px / 1.5rem), providing an approachable frame for high-density academic and market intelligence data.
- **Cards, Inner Panels, & Dialogs:** Use `rounded-lg` (16px / 1.0rem) to nest cleanly within parent bento layouts without corner collisions.
- **Interactive Controls (Buttons, Inputs, Selectors):** Feature a balanced `rounded` (8px / 0.5rem) radius for crisp clickable authority.
- **Telemetry Chips & Status Badges:** Apply fully pill-shaped radii (9999px) to signal atomic data status and isolate them visually from structural grid corners.

## Components

### Buttons
- **Primary:** Solid `#6D28D9` fill with pure `#FFFFFF` typography. Crisp 8px border radius, subtle hover elevation shift to `#4C1D95` accompanied by an ambient glow (`box-shadow: 0 8px 20px -2px rgba(109, 40, 217, 0.3)`).
- **Secondary / Ghost:** Transparent surface with a 1px `#E9E4F3` hairline stroke, `#1F1535` text. On hover, transitions to `#F5F3FF` fill with a `#6D28D9` fine outline.
- **AI Assist Action:** Gradient edge fill (`linear-gradient(135deg, #6D28D9, #8B5CF6)`), featuring a 12px leading spark icon and crisp typographic contrast.

### Micro-Badges & Skill Nodes
- **Mastered Competency:** `#16A34A` text on a soft green-tinted background (`rgba(22, 163, 74, 0.08)`), framed by a 1px border of `rgba(22, 163, 74, 0.25)`.
- **Identified Gap / High Demand:** `#6D28D9` text on a `#EDE9FE` pill, incorporating an active telemetry dot (`#8B5CF6`).
- **Emerging Role Match:** `#1F1535` text on a `#FFFFFF` pill, featuring an `#E9E4F3` border and uppercase `label-caps` typography.

### Bento Intelligence Cards
- Configured with pure `#FFFFFF` surfaces, a continuous 1px `#E9E4F3` hairline border, and 24px internal padding (`space-md` to `space-lg`).
- Modular headers contain categorical uppercase subtitles, dominant bold titles, and top-right micro-metric chips. Content areas accommodate radar skill vectors, predictive salary correlations, or tabular course alignments.

### Metric Readout Pods
- Compact analytical displays pairing an oversized `data-metric` figure (`#1F1535`) with an integrated directional badge (`#16A34A` for positive career readiness deltas).
- Sub-labels maintain strict `label-caps` styling in `#6B6478` with 4px top clearance.

### Form Inputs & Selectors
- Backgrounds leverage `#FFFFFF` surrounded by a persistent 1px `#E9E4F3` outline.
- Active typing or dropdown focus activates an immediate `#6D28D9` rim and a soft ambient violet ring (`box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15)`). Placeholder copy is fixed at `#6B6478`.

### Selection Controls (Checkboxes & Radios)
- Distinct 18px square modules (or circular radios) utilizing 1px `#E9E4F3` borders on `#FFFFFF`.
- Checked states trigger an instant `#6D28D9` fill displaying a sharp white vector checkmark, reinforcing affirmative curriculum selection.